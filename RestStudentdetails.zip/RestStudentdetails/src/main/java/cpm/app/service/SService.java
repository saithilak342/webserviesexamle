package cpm.app.service;

import java.util.List;

import com.app.pojo.Spojo;

public interface SService {
	public void savestudent(Spojo user);
	public void updatestudent(Spojo user);
	public void deletestudent(int sId);
	public List<Spojo> getstudent(int sId);
	public List<Spojo> getAllstudent();
	public String getRealPath(String string);
}
