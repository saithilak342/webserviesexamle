package cpm.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.Sdao;
import com.app.pojo.Spojo;

@Service
@Transactional
public class SServiceimpl implements SService{
@Autowired
private Sdao sdao;
	public void savestudent(Spojo user) {
		sdao.savestudent(user);
	}
	public void updatestudent(Spojo user) {
		// TODO Auto-generated method stub
		sdao.updatestudent(user);
	}
	public void deletestudent(int sId) {
		// TODO Auto-generated method stub
		sdao.deletestudent(sId);
	}
	public List<Spojo> getstudent(int sId) {
		// TODO Auto-generated method stub
		return sdao.getstudent(sId);
	}
	public List<Spojo> getAllstudent() {
		// TODO Auto-generated method stub
		return sdao.getAllstudent();
	}
	public String getRealPath(String string) {
		// TODO Auto-generated method stub
		return sdao.toString();
	}
}
