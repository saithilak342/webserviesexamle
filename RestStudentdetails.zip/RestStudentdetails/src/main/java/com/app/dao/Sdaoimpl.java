package com.app.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojo.Spojo;

@Repository("userDao")
public class Sdaoimpl implements Sdao{
@Autowired
private SessionFactory sessionFactory;
public void savestudent(Spojo user) {
	// TODO Auto-generated method stub
	sessionFactory.getCurrentSession().saveOrUpdate(user);
	
}
public void updatestudent(Spojo user) {
	// TODO Auto-generated method stub
	sessionFactory.getCurrentSession().update(user);
}
public void deletestudent(int sId) {
	// TODO Auto-generated method stub
	sessionFactory.getCurrentSession().createQuery("delete from Spojo where sId=" +sId).executeUpdate();  
}
public List<Spojo> getstudent(int sId) {
	Session session=this.sessionFactory.openSession();
	Transaction tx=session.beginTransaction();
	Query q = session.createQuery("from Spojo where sId=:sId");
	q.setParameter("sId", sId);
	List l = q.list();
	System.out.println("retrieve particular sId");
	System.out.println(l);
	tx.commit();
	session.close();
	return l;
}
public List<Spojo> getAllstudent() {
	// TODO Auto-generated method stub
	Session session=this.sessionFactory.openSession();
	Transaction tx=session.beginTransaction();
	Query q = session.createQuery("from Spojo");
	List l = q.list();

	System.out.println(l);
	tx.commit();
	session.close();
	return l;
}
public String getRealPath(String string) {
	// TODO Auto-generated method stub
	return sessionFactory.getCurrentSession().toString();
}

}
