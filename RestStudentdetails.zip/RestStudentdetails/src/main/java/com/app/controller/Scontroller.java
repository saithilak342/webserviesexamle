package com.app.controller;



import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.sql.rowset.serial.SerialException;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import java.io.File;
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import com.app.pojo.Spojo;

import cpm.app.service.SService;


import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
@RestController
@RequestMapping("/student")
public class Scontroller {
@Autowired
private SService service;

@RequestMapping(value="/add",method=RequestMethod.POST,consumes={MediaType.APPLICATION_JSON_VALUE},produces={MediaType.APPLICATION_JSON_VALUE})
public void addstudent(@RequestBody Spojo user) {
	service.savestudent(user);
	
}
@RequestMapping(value="/update",method=RequestMethod.PUT,consumes={MediaType.APPLICATION_JSON_VALUE},produces={MediaType.APPLICATION_JSON_VALUE})
public void updatestudent(@RequestBody Spojo user) {
	service.updatestudent(user);
}
@GetMapping(value="/delete/{sId}",produces={MediaType.APPLICATION_JSON_VALUE})
public void Deletestudent(@PathVariable("sId") int sId) {
	service.deletestudent(sId);
}
@GetMapping(value="/{sId}",produces={MediaType.APPLICATION_JSON_VALUE})
public List<Spojo> getstudent(@PathVariable("sId") int sId){
	return service.getstudent(sId);
}
@GetMapping(value="/all",produces={MediaType.APPLICATION_JSON_VALUE})
public List<Spojo> getallstudent(){
	return service.getAllstudent();	
}
@Autowired
ServletContext context;

@RequestMapping(value = "/fileupload", headers=("content-type=multipart/*"), method = RequestMethod.POST)
public ResponseEntity<Spojo> upload(@RequestParam("file") MultipartFile inputFile) {
	Spojo fileInfo = new Spojo();
 HttpHeaders headers = new HttpHeaders();
 if (!inputFile.isEmpty()) {
	   try {
		    String originalFilename = inputFile.getOriginalFilename();
		    File destinationFile = new File(context.getRealPath("/WEB-INF/uploaded")+  File.separator + originalFilename);
		    inputFile.transferTo(destinationFile);
		    fileInfo.setFileName(destinationFile.getPath());
		    fileInfo.setFileSize(inputFile.getSize());
		    headers.add("File Uploaded Successfully - ", originalFilename);
		    return new ResponseEntity<Spojo>(fileInfo, headers, HttpStatus.OK);
		   } catch (Exception e) {    
		    return new ResponseEntity<Spojo>(HttpStatus.BAD_REQUEST);
		   }
		  }else{
		   return new ResponseEntity<Spojo>(HttpStatus.BAD_REQUEST);
		  }
		 }
}